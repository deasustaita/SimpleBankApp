from models.Customer import Customer

from typing import List, Optional
from bson import ObjectId


# manipulation of data occurs here
class CustomerRepository:
    def __init__(self,database):
        self._data = database["Customer"]


    def find_customers(self) -> List[Customer]:
        # return the data of all customers in the database
        customers = self._data.find()
        return [Customer(**doc) for doc in customers]

    def find_by_id(self, customer_id: str) -> Optional[Customer]:
        if not ObjectId.is_valid(customer_id):
            return None
        customer = self._data.find_one({"_id": ObjectId(customer_id)})
        return customer

    def make_customer(self, customer: Customer) -> Customer:
        self._data.append(customer)
        return customer

    def update_customer(self, customer_id: str, up_customer: Customer) -> Optional[Customer]:
        for index, customer in enumerate(self._data):
            if customer.id == customer_id:
                up_customer.id = customer_id
                self._data[index] = up_customer
                return up_customer
        return None

    def remove_customer(self, customer_id: str):
        for index, customer in enumerate(self._data):
            if customer.id == customer_id:
                self._data.pop(index)
                return True
        return False

## wrap in a ResponseEntity rather than return a list
# 1 example of getall getbyid post put delete rest method call(controller -> service -> repo) 